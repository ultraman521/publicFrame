package com.news.guagua.net;

/**
 * 返回码
 */
public class Result {
    public static final int FAIL = -1;
    public static final int OK = 0;

}

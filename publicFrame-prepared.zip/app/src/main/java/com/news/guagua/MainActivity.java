package com.news.guagua;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.news.guagua.utils.ToastUtils;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ToastUtils.show("hhhhh");
    }
}

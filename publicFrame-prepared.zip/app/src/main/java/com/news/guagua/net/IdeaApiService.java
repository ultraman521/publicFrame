package com.news.guagua.net;

/**
 * 不验证签名：KennyTest
 */

public interface IdeaApiService {
    /**
     * 网络请求超时时间毫秒
     */
    int DEFAULT_TIMEOUT = 20000;
}

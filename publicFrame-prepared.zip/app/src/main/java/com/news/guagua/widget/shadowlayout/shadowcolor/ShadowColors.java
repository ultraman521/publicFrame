package com.news.guagua.widget.shadowlayout.shadowcolor;

public class ShadowColors {
    public static int black = 0xff000000;
    public static int white = 0xffffffff;
    public static int eee = 0xffEEEEEE;
    public static int ddd = 0xffDDDDDD;
    public static int blue33 = 0xff3399FE;
//    public static int black=0xff000000;
//    public static int black=0xff000000;
}

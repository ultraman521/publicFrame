package com.news.guagua.net;

import java.util.Random;
import java.util.Scanner;

public class UrlUtils {
    int DEFAULT_TIMEOUT = 20000;

    public String host;
    private String Image_url = "";


    private static class SingleHolder {
        private static final UrlUtils SINGLE = new UrlUtils();
    }

    public static UrlUtils getInstance() {
        return UrlUtils.SingleHolder.SINGLE;
    }

    public boolean isRandom;


    /**
     * @return
     */
    public String getUrl() {
        return "";
    }


    public void setUrl(boolean random) {
        isRandom = random;
    }

    public void sethost(String host) {
        this.host = host;
    }

    public String getImage_url() {
        return Image_url;
    }

    public void setImage_url(String image_url) {
        Image_url = image_url;
    }

    public static void main(String[] arg){
        Scanner scanner = new Scanner(System.in);
        String str;
        while (true){
            str = scanner.next();
            str = str.replace("吗","");
            str = str.replace("?","!");
            str = str.replace("？","!");
            str = str.replace("你","我");
            str = str.replace("么","");
            System.out.println(str);

        }
    }
}

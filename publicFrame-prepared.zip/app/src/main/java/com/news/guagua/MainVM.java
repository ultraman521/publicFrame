package com.news.guagua;

import android.app.Application;
import android.support.annotation.NonNull;

import me.goldze.mvvmhabit.base.BaseViewModel;

public class MainVM extends BaseViewModel {
    public MainVM(@NonNull Application application) {
        super(application);
    }
}
